<?php 
	session_start();
	if($_POST['mail']==null)
		echo "email";
	else if (!filter_var($_POST['mail'], FILTER_VALIDATE_EMAIL))
		echo 'email_error';
	else if($_POST['pass']==null)
		echo "pass";
	else{
			if(checkLogin($_POST['mail'], $_POST['pass']) == "")
				echo "null";
			else
				{
					$_SESSION['login'] = checkLogin($_POST['mail'], $_POST['pass']);
					echo checkLogin($_POST['mail'], $_POST['pass']);
				}
		}

	function checkLogin($mail, $pass){
		$conn = pg_connect("host=localhost port=5432 dbname=tiki user=postgres password=123456");
		$tmp = "select user_id from user_info where user_email = '$mail' AND user_pass = '$pass'";
		$result = pg_query($conn,$tmp);
		$row = pg_fetch_assoc($result);
		return $row['user_id'];
	}
 ?>