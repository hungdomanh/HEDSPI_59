<!DOCTYPE html>
<?php 
	session_start();

 ?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Login | E-Shopper</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/sweet-alert.css">
	<script type="text/javascript" src="js/jquery.js"></script>
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<?php include 'header.php'; ?>
	
	<section id="form"><!--form-->
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h2>Login to your account</h2>
						<form action="#">
							<input type="email" placeholder="Email Address" class="mailuser" />
							<input type="password" placeholder="Password" class="passuser"/>
							
							<button type="submit" class="btn btn-default" id="clickme" onclick="event.preventDefault(); load_ajaxlogin();" >Login</button>
						</form>


					</div><!--/login form-->
				</div>
				<div class="col-sm-1">
					<h2 class="or">OR</h2>
				</div>
				<div class="col-sm-4">
					<div class="signup-form"><!--sign up form-->
						<h2>New User Signup!</h2>
							<form action="#" id= "signup">
							<input type="text" placeholder="Name" class="name"/>
							<input type="email" placeholder="Email Address" class="email"/>
							<input type="password" placeholder="Password" class="pass"/>
							<div class="ktpass" style="color:red"></div>
							<input type="password" placeholder="Password Confirm" class="passconfirm"/>
							<div class="ktpassconfirm" style="color:red"></div>
							<button type="submit" class="btn btn-default" id="clickme" onclick="load_ajax();event.preventDefault();" >Signup</button>
							</form>

				        <script type="text/javascript">
								$(".pass").keypress(function() {
								var str= $(this).val();//var la lay gia tri
								// swal(str);
								if(str.length < 7){
									$(".ktpass").text("Phai lon hon 8 ky tu");
								}
								else{
									$(".ktpass").text("");
								}
							});
						</script>

						<script type="text/javascript">
							$(".passconfirm").keyup(function() {
								$pass1 = $(this).val();
								$pass2 = $('.pass').val();
								if($pass1 != $pass2)
									$(".ktpassconfirm").text("Mật khẩu không trùng khớp");
								else
									$(".ktpassconfirm").text("");
							});
						</script>

					</div><!--/sign up form-->
					
				</div>
			</div>
		</div>
	</section><!--/form-->


	<script src="js/price-range.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
    <script src="js/sweet-alert.js"></script>
</body>
</html>