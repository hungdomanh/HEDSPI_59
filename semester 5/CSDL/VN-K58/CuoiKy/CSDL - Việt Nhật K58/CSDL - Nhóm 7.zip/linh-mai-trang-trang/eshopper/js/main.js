/*price range*/

 $('#sl2').slider();

	var RGBChange = function() {
	  $('#RGB').css('background', 'rgb('+r.getValue()+','+g.getValue()+','+b.getValue()+')')
	};	
		
/*scroll to top*/

$(document).ready(function(){
	$(function () {
		$.scrollUp({
	        scrollName: 'scrollUp', // Element ID
	        scrollDistance: 300, // Distance from top/bottom before showing element (px)
	        scrollFrom: 'top', // 'top' or 'bottom'
	        scrollSpeed: 300, // Speed back to top (ms)
	        easingType: 'linear', // Scroll to top easing (see http://easings.net/)
	        animation: 'fade', // Fade, slide, none
	        animationSpeed: 200, // Animation in speed (ms)
	        scrollTrigger: false, // Set a custom triggering element. Can be an HTML string or jQuery object
			scrollTarget: false, // Set a custom target element for scrolling to the top
	        scrollText: '<i class="fa fa-angle-up"></i>', // Text for element, can contain HTML
	        scrollTitle: false, // Set a custom <a> title if required.
	        scrollImg: false, // Set true to use image
	        activeOverlay: false, // Set CSS color to display scrollUp active point, e.g '#00FFFF'
	        zIndex: 2147483647 // Z-Index for the overlay
		});
	});
	

});

function add_to_cart(id){
	$.ajax({
		url: 'cart_function.php?',
		type: 'POST',
		dataType: 'text',
		data: {add_item: id},
		success : function(data){
			if (data =='error'){
				swal({title: "Xin lỗi! Sản phẩm này hiện không còn đủ số lượng bạn cần mua!",type: "error"});
				// location.reload(true);
				}
			else				                        
			swal({title: data + " đã được đưa vào giỏ hàng",type: "success", confirmButtonText: "OK", closeOnConfirm: false}, function(isConfirm){
				  if (isConfirm) {
				   location.reload(true);
				  } 
				});
			
		}
	});
}

function load_ajaxlogin(){
     $.ajax({
        url : "check.php",
        type : "post",
        dataText : "text",
        data:{
            mail : $('.mailuser').val(),
            pass : $('.passuser').val()
        },
        success : function(data){
        	// alert(data);
        	if(data == "email")
        		swal({title: "Bạn chưa điền email",type: "error"});
        	else if(data == "email_error")
        		swal({title: "Định dạng email không đúng",type: "error"});
        	else if(data =="pass")
        		swal({title: "Bạn chưa điền mật khẩu",type: "error"});
        	else if(data =="null")
        		swal({title: "Email hoặc mật khẩu không trùng khớp",type: "error"});
        	else
        		{
        			swal({title: "Đăng nhập thành công",type: "success", confirmButtonText: "OK", closeOnConfirm: false}, function(isConfirm){
					  if (isConfirm) {
					    window.location=("cart.php");
					  } 
					});
        		}
        }
     });
}

function load_ajax(){
     $.ajax({
        url : "adduser.php",
        type : "post",
        dataText : "text",
        data:{
            name : $('.name').val(),
            email : $('.email').val(),
            pass : $('.pass').val(),
            passconfirm : $('.passconfirm').val()
        },
        success : function(data){
        	// alert(data);
            if(data == "name")
        		swal({title: "Bạn chưa điền tên",type: "error"});
            else if(data == "email")
        		swal({title: "Bạn chưa điền email",type: "error"});
            else if(data == "email_error")
        		swal({title: "Định dạng email không đúng",type: "error"});
            else if(data == "email_exits")
        		swal({title: "Tài khoản đã tồn tại",type: "error"});
            else if(data == "pass")
        		swal({title: "Bạn chưa điền mật khẩu",type: "error"});
            else if(data == "pass_short")
        		swal({title: "Mật khẩu của bạn phải đủ 8 kí tự trở lên",type: "error"});
            else if(data == "passconfirm")
        		swal({title: "Bạn chưa điền password confirm",type: "error"});
            else if(data == "pass_error")
        		swal({title: "Password và password confirm không trùng nhau",type: "error"});
            else
            	{
            		swal({title: "Thành công",type: "success", confirmButtonText: "OK", closeOnConfirm: false}, function(isConfirm){
					  if (isConfirm) {
            			// document.getElementById("signup").reset();
            			location.reload(true);
					  } 
					});
				}
        }
     });
}

function buy(){
	event.preventDefault();
	$.ajax({
		url : "buy.php",
		type : "post",
		datatype : "text",
		data : {
			city: $('#city').find(':selected').val(),
			district: $('#district').find(':selected').val(),
			address : $('.user_address').val(),
			receiver : $('.receiver').val(),
			phone : $('.phone').val(),
		},
		success : function(data){
			//alert(data);
			if(data =="login")
			swal({title: "Phải đăng nhập trước khi mua hàng",type: "error", confirmButtonText: "OK", closeOnConfirm: false}, function(isConfirm){
										  if (isConfirm) {
		                        			window.location=("login.php");
										  } 
										});

			else if(data == "null")
				swal({title: "Chọn sản phẩm cần mua",type: "error"});
			else if(data == "city" ||data == "district"||data == "address"||data == "receiver"||data == "phone")
				swal({title: "Bạn cần điền thông tin địa chỉ",type: "error"});
			else if(data.indexOf("error") >= 0){
				var name = data.split('|')[1];
				var quantity = data.split('|')[2];
				swal({title: "Sản phẩm "+name+" chỉ còn "+quantity+" quyển, mong quý khách thông cảm.",type: "error",confirmButtonText: "OK", closeOnConfirm: false}, function(isConfirm){
					if (isConfirm) {
					window.location=("cart.php");
					} 
				});

			}
			else
			swal({title: "Mua hàng thành công",type: "success", confirmButtonText: "OK", closeOnConfirm: false}, function(isConfirm){
										  if (isConfirm) {
		                        			window.location.href = "order-details.php?id="+data;

										  } 
										});

		}
	});
}
function add_quantity(id){
	$.ajax({
		url : "cart_function.php",
		type : "post",
		datatype : "text",
		data : {add_cart : id},
		success : function(data){
			if (data == "error")
				swal({title: "Xin lỗi! Sản phẩm này hiện không còn đủ số lượng bạn cần mua!",type: "error"});
			else
				location.reload(true);
		}
	});
}
function minus_quantity(id){
	$.ajax({
		url : "cart_function.php",
		type : "post",
		datatype : "text",
		data : {minus_cart : id},
		success : function(data){
			location.reload(true);
		}
	});
}
function remove_cart(id){
	$.ajax({
		url : "cart_function.php",
		type : "post",
		datatype : "text",
		data : {remove_cart : id},
		success : function(data){
			location.reload(true);
		}
	});
}

function deleted_order(id){
	swal({
	  title: "Hủy đơn hàng?",
	  text: "Bạn có chắc chắn muốn hủy đơn hàng này?",
	  type: "warning",
	  showCancelButton: true,
	  confirmButtonColor: "#DD6B55",
	  confirmButtonText: "Đồng ý",
	  cancelButtonText: "Không",
	  closeOnConfirm: false,
	  closeOnCancel: true
	},
	function(isConfirm){
		if (isConfirm) {
			$.ajax({
				url : "deleted_order.php",
				type : "post",
				datatype : "text",
				data : {order : id},
				success : function(data){
					swal({title: "Hủy đơn hàng thành công",type: "success", confirmButtonText: "OK", closeOnConfirm: false}, function(isConfirm){
						if (isConfirm) {
				            window.location.href = "order-lists.php?id="+data;
						 } 
					});
				}
			});
		}
	});			
}

function loadCity(){
    			$.ajax({
    				type: "POST",
    				url: "quan.php",
    				data: "get=city"
    			})
    			.done(function(data) {
    				result = JSON.parse(data);
    				$(result).each(function(){
    					$("#city").append($('<option>',{
    						value: this.id,
    						text: this.ten
    					}));
    				})
    			});
    		}


    	function loadDistrict(cityId){
		        $("#district").children().remove();
		        $.ajax({
		            type: "POST",
		            url: "quan.php",
		            data: "get=district&cityId=" + cityId
		            }).done(function( data ) {
		            	// alert(data);
		            	result = JSON.parse(data);
		            	
		                $(result).each(function(){
		                    $("#district").append($('<option>', {
		                        value: this.id,
		                        text: this.ten
		                    }));
		                })
		            });
		}				   