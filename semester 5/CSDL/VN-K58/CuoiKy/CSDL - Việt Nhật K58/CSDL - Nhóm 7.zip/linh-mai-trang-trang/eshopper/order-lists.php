<!DOCTYPE html>
<?php 
	session_start();
	$conn = pg_connect("host=localhost port=5432 dbname=tiki user=postgres password=123456");
 ?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Order | E-Shopper</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/sweet-alert.css">

    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<?php include 'header.php'; ?>

	<section id="cart_items">
		<div class="container">
			<div class="breadcrumbs">
				<ol class="breadcrumb">
				  <!-- <li><a href="#">Home</a></li> -->
				  <h4 class="active">Lịch sử mua hàng</h4>'
				</ol>
			</div>
			<div class="table-responsive cart_info">
				<table class="table table-condensed">
					<thead>
						<tr class="cart_menu">
							<td class="id">Đơn hàng</td>
							<td class="date">Ngày</td>
							<td class="quantity">Số lượng sách</td>
							<td class="total">Số tiền</td>
							<td class="note">Ghi chú</td>
							<td></td>
						</tr>
					</thead>
					<tbody>
						<?php 
							$id = $_GET['id'];
							$sql = "select * from order_info where user_id = '$id'";
							$result = pg_query($conn,$sql);
							while ($item=pg_fetch_assoc($result)) {
								$order_id = $item['order_id'];
								$status = $item['status'];
								if ($status==0){
									$note = "Đã hủy";
									$tmp = "select sum(quantity) as s FROM order_item_deleted Where order_id = '$order_id'";
								}
								else{
									$note = "";
									$tmp = "select sum(quantity) as s FROM order_item Where order_id = '$order_id'";
								}
								$result1 = pg_query($conn,$tmp);
								$row = pg_fetch_assoc($result1);
								$quantity = $row['s']; 
								$total = $item['total'];
								$date = $item['order_created'];
								echo '<tr>
										<td class="order_id">
											<h4>#'.$order_id.'</h4>
										</td>
										<td class="order_date">
											<h4>'.$date.'</h4>
										</td>
										<td class="order_quantity">
											<h4>'.$quantity.'</h4>
										</td>
										<td class="order_total">
											<h4 class="cart_total_price">'.$total.'.000 đ</h4>
										</td>
										<td class="order_note">
											<h4>'.$note.'</h4>
										</td>
										<td class="order_details">
											<a class="btn btn-default" href="order-details.php?id='.$order_id.'" style="margin-left:5em">Xem chi tiết</a>
											&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp';
								if ($status==1)			
									echo '<a class="deleted" onclick="deleted_order('.$order_id.')"><i class="fa fa-times"></i></a>';
								echo'
										</td>

									</tr>';
							}
						 ?>
						
					</tbody>
				</table>
			</div>
		</div>
	</section> <!--/#order_list-->

	
    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
    <script src="js/sweet-alert.js"></script>

</body>
</html>