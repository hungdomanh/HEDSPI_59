
<header id="header"><!--header-->
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
						<div class="mainmenu pull-left">
							<ul class="nav navbar-nav collapse navbar-collapse">
								<li><a href="index.php" class="active">Home</a></li>
								<!-- <li class="dropdown"><a href="#">Shop<i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">
                                        
										<li><a href="checkout.html">Checkout</a></li> 
										<li><a href="cart.html">Cart</a></li> 
										<li><a href="login.html">Login</a></li> 
                                    </ul>
                                </li>  -->
                                <?php 
									if(isset($_SESSION['login']))
										{
											$id = $_SESSION['login'];
											echo '<li><a href="order-lists.php?id='.$id.'"></i>Lịch sử mua hàng</a></li>';
										} 
								?>
								<!-- <li><a href="contact-us.html">Contact</a></li> -->
							</ul>
						</div>
					</div>
					
					<div class="col-sm-4 cod-sm-offset-8">
						<div class="shop-menu pull-right">
							<ul class="nav navbar-nav">
								<?php 
									if(isset($_SESSION['login']))
										{
											$id = $_SESSION['login'];
											$conn = pg_connect("host=localhost port=5432 dbname=tiki user=postgres password=123456");
											$tmp = "select user_name from user_info where user_id = '$id'";
											$result = pg_query($conn,$tmp);
											$row = pg_fetch_assoc($result);
											echo '<li><a href="#"><i class="fa fa-user"></i> '.$row['user_name'].'</a></li>';
										} 
									else
										echo '<li><a href="#"><i class="fa fa-user"></i> Tài khoản</a></li>';
								?>
								
								<li><a href="cart.php"><i class="fa fa-shopping-cart"></i> Giỏ hàng
									<?php 
										if(empty($_SESSION['cart'])){
											$_SESSION['cart'] = array();
										}
										$sum = 0;

										foreach ($_SESSION['cart'] as $key => $value) {
											$sum += $value;
										}
										if($sum>0)
											echo '<span class="badge" style="background:red">'.$sum.'</span>';
									 ?>
								</a></li>
								<?php 
									if(isset($_SESSION['login']))
										echo '<li><a href="logout.php"><i class="fa fa-lock"> Đăng xuất</i></a></li>';
									else
										echo '<li><a href="login.php"><i class="fa fa-lock"> Đăng nhập</i></a></li>';
								 ?>
								
							</ul>
						</div>
					</div>

					<div class="col-sm-2">
						<div class="search_box pull-right">
							<input type="text" placeholder="Search"/>
						</div>
					</div>

				</div>
			</div>
		</div><!--/header-middle-->
	
		<div class="header-bottom"><!--header-bottom-->
			
		</div><!--/header-bottom-->
	</header><!--/header-->