<!DOCTYPE html>
<?php 

	session_start();

 ?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Checkout | E-Shopper</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/sweet-alert.css">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<?php include 'header.php'; ?>

	<section id="do_action">
		<div class="container">
			<div class="heading">
				<h3>Thông tin sản phẩm</h3>
			</div>
			<div class="row">
				<div class="col-sm-6">
					<div class="chose_area">
						<!-- <ul class="user_option">
							<li>
								<input type="checkbox">
								<label>Thanh toán tiền mặt khi nhận hàng</label>
							</li>
							<li>
								<input type="checkbox">
								<label>Thẻ ATM</label>
							</li>
						</ul> -->
						<ul class="user_info">
							<li class="single_field">
								<label>Thành phố:</label>
								<select id="city" name="city">
									<option>-----</option>
								</select>
								
							</li>
							<li class="single_field">
								<label>Quận:</label>
								<select class="quan" id="district" name="district"></select>
							
							</li>
						</ul>

						<div class="shopper-info">
							<form>
								<input type="text" placeholder="Địa chỉ người nhận" class="user_address">
								<input type="text" placeholder="Tên người nhận" class="receiver">
								<input type="text" placeholder="Số điện thoại người nhận" class = "phone">
							</form>
						</div>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="total_area">
						<?php 
							$sum = $_SESSION['sum'];
							echo '
								<ul>
									<li>Tổng tiền các sản phẩm: <span>'.$sum.'.000 đ</span></li>
									<li>Thuế: <span>0đ</span></li>
									<li>Phí dịch vụ: <span>Free</span></li>
									<li>Tổng tiền: <span>'.$sum.'.000 đ</span></li>
								</ul>
							';
						 ?>
							<a class="btn btn-default check_out" href="" onclick="buy(); event.preventDefault();">Mua</a>
					</div>
				</div>
			</div>
		</div>
	</section><!--/#do_action-->
	

    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
    <script src="js/sweet-alert.js"></script>


    <script type="text/javascript">
    	loadCity();
    	
    	
    	$(document).ready(function(){
    		$('.quan').hide();
    		$('#city').change(function() {
    			loadDistrict($(this).find(':selected').val());
    			$('.quan').show();
    		});
    		
    	});


    	   
    </script>
</body>
</html>