<!DOCTYPE html>
<?php 
	session_start();

 ?>
<html lang="en">
<?php 
	// kết nối với postgre
	$conn = pg_connect("host=localhost port=5432 dbname=tiki user=postgres password=123456");
?>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Product Details | E-Shopper</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/sweet-alert.css">

    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	
	<?php include 'header.php'; ?>
	
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Danh mục</h2>
						<div class="panel-group category-products" id="accordian">
							
							<?php
								$result = pg_query($conn,"SELECT * FROM category");
								while ($row = pg_fetch_assoc($result)) {
									echo '<div class="panel panel-default">
											<div class="panel-heading">
												<h4 class="panel-title"><a href="category-products.php?category_id='.$row['category_id'].'&page=1">'.$row['category_name'].'</a></h4>
											</div>
										</div>';
								}
							  ?>
						</div><!--/category-products-->
					
						<div class="brands_products"><!--brands_products-->
							<h2>Tác giả</h2>
							<?php 
								echo '
								<div class="brands-name">
								<ul class="nav nav-pills nav-stacked">
								';
								$result = pg_query($conn,"SELECT author, COUNT(id) FROM book_info GROUP BY(author) ORDER BY COUNT(id) DESC limit 5");
								while ($row = pg_fetch_assoc($result)) {
									echo '<li><a href="author.php?author='.$row['author'].'"> <span class="pull-right">('.$row['count'].')</span>'.$row['author'].'</a></li>';
								}
								echo '
								</ul>
								</div>
								';
							 ?>
							
								
						</div><!--/brands_products-->
					
					</div>
				</div>
				
				<div class="col-sm-9 padding-right">
					<div class="product-details"><!--product-details-->
						<div class="col-sm-5">
							<div class="view-product">
								<?php 
									$id = $_GET['id'];
									$result = pg_query($conn,"SELECT * FROM category natural join book_info WHERE id = '$id';");

									// $result = pg_query($conn,"SELECT * FROM book_info WHERE id = '$id'");
									$row = pg_fetch_assoc($result);
									echo '
										<img src="'.$row['image'].'" alt="" />
									';
									$category_id = $row['category_id'];
									$id = $row['id'];
								 ?>

							</div>
							

						</div>
						<div class="col-sm-7">
							<div class="product-information"><!--/product-information-->
								<!-- <img src="images/product-details/new.jpg" class="newarrival" alt="" /> -->
								<?php 
									echo '<h2>'.$row['name'].'</h2>';
									echo '
									<span>
									<span>'.$row['price'].'</span>
									<button type="button" class="btn btn-fefault cart" onclick="add_to_cart('.$row['id'].'); event.preventDefault();">
										<i class="fa fa-shopping-cart"></i>
										Add to cart
									</button>
									</span>
									';


									echo '
									<p><b>Tác giả:</b> '.$row['author'].'</p>
									<p><b>Thể loại:</b> '.$row['category_name'].'</p>
									';
								 ?>
								
								
								
								
							</div><!--/product-information-->
						</div>
					</div><!--/product-details-->
					
					<br/>
					<div class="recommended_items"><!--recommended_items-->
						<h2 class="title text-center">Chi tiết</h2>
						<?php 
							echo '<h4 style = "color: #6666ff">'.$row['name'].'</h4>';
							echo '<p>'.$row['description'].'</p>';
						 	$view=$row['view']+1;

						 ?>
						 <br/>

					</div>
					<table class="table table-condensed">
					 	<tr class="info">
         					<td>Nhà xuất bản</td>
          					<td><?php echo $row['publisher']; ?></td>
        				</tr>
				        <tr class="active">
				          <td>Trọng lượng vận chuyển (gram)</td>
				          <td><?php echo $row['mass']; ?></td>
				        </tr>
				        <tr class="info">
				          <td>Kích thước</td>
				          <td><?php echo $row['size']; ?></td>
				        </tr>
				        <tr class="active">
				          <td>Tác giả</td>
				          <td><?php echo $row['author']; ?></td>
				        </tr>
				        <tr class="info">
				          <td>Số trang</td>
				          <td><?php echo $row['number_of_page']; ?></td>
				        </tr>
				        <tr class="active">
				          <td>Ngày xuất bản</td>
				          <td><?php echo $row['date_published']; ?></td>
				        </tr>
				        <tr class="info">
				          <td>Danhh mục</td>
				          <td><?php echo $row['category_name']; ?></td>
				        </tr>
				       
					</table>
					<?php 
						$result= pg_query($conn,  "UPDATE book_info SET view=$view WHERE id='$id' ");
					 ?>
					<br/>
					<div class="recommended_items"><!--recommended_items-->
						<h2 class="title text-center">Tác phẩm cùng loại</h2>
						
						<div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
							<div class="carousel-inner">
								<div class="item active">	

									<?php 
									$tmp = "SELECT category_id, name, image, price,id FROM book_info WHERE category_id = '$category_id' AND id !='$id'  Limit 3 OFFSET 0";
									// echo $tmp;
									$result = pg_query($conn,$tmp);
								while ($row = pg_fetch_assoc($result)) {
									echo '
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
												<a href="product-details.php?id='.$row['id'].'">
													<img src="'.$row['image'].'" alt="" />
													<h2>'.$row['price'].'</h2>
													<p>'.$row['name'].'</p>
													<button type="button" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</button>
												</a>
												</div>
											</div>
										</div>
									</div>
								';
								}
								
								?>	

								</div>
								<div class="item">	
									<?php 
									$tmp = "SELECT category_id, name, image, price,id FROM book_info WHERE category_id = '$category_id' AND id !='$id'  Limit 3 OFFSET 3";
									// echo $tmp;
									$result = pg_query($conn,$tmp);
								while ($row = pg_fetch_assoc($result)) {
									echo '
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
												<a href="product-details.php?id='.$row['id'].'">
													<img src="'.$row['image'].'" alt="" />
													<h2>'.$row['price'].'</h2>
													<p>'.$row['name'].'</p>
													<button type="button" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</button>
												</a>
												</div>
												
											</div>
										</div>
									</div>
								';
								}
								
								?>	
									
								</div>
								<div class="item">	
									<?php 
									$tmp = "SELECT category_id, name, image, price,id FROM book_info WHERE category_id = '$category_id' AND id !='$id'  Limit 3 OFFSET 6";
									// echo $tmp;
									$result = pg_query($conn,$tmp);
								while ($row = pg_fetch_assoc($result)) {
									echo '
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
												<a href="product-details.php?id='.$row['id'].'">
													<img src="'.$row['image'].'" alt="" />
													<h2>'.$row['price'].'</h2>
													<p>'.$row['name'].'</p>
													<button type="button" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</button>
												</a>
												</div>
												
											</div>
										</div>
									</div>
								';
								}
								
								?>	
									
								</div>
							</div>
							 <a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
								<i class="fa fa-angle-left"></i>
							  </a>
							  <a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
								<i class="fa fa-angle-right"></i>
							  </a>			
						</div>
					</div><!--/recommended_items-->
					
				</div>
			</div>
		</div>
	</section>

    <script src="js/jquery.js"></script>
	<script src="js/price-range.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
    <script src="js/sweet-alert.js"></script>

</body>
</html>