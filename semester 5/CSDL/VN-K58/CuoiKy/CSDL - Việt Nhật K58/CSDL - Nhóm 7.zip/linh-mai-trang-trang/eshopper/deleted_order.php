<?php 
	session_start();
	$id =  $_POST['order'];
	$conn = pg_connect("host=localhost port=5432 dbname=tiki user=postgres password=123456");
 			
 		// 	$tmp = "UPDATE order_info
			// 		SET status=0
			// 		WHERE order_id='$id';
			// 		";
			// $update = pg_query($conn,$tmp);

			// $tmp1 = "select * from order_item where order_id='$id'";
			// $result = pg_query($conn,$tmp1);
			// while($row = pg_fetch_assoc($result)){
			// 	$order_id = $row['order_id'];
			// 	$item_id = $row['item_id'];
			// 	$quantity = $row['quantity'];

			// 	$tmp2 = "INSERT INTO order_item_deleted(order_id, item_id, quantity) VALUES ('$order_id','$item_id', '$quantity')";
			// 	$insert_data = pg_query($conn,$tmp2);
			// }

	$tmp2 = "delete from order_item where order_id='$id'";
	$result = pg_query($conn,$tmp2);
	echo $_SESSION['login'];
 ?>