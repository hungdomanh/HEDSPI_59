<!DOCTYPE html>
<?php 
	session_start();

 ?>
<html lang="en">
<?php 
	include 'function.php';
	// kết nối với postgre
	$conn = pg_connect("host=localhost port=5432 dbname=tiki user=postgres password=123456");
	// echo $conn;
	if(isset($_GET['page']))
		$page=$_GET['page']-1;
	else
		$page = 0;
?>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Shop | E-Shopper</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/sweet-alert.css">

    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<?php include 'header.php'; ?>
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Danh mục</h2>
						<div class="panel-group category-products" id="accordian">
							<?php
								$result = pg_query($conn,"SELECT * FROM category");
								while ($row = pg_fetch_assoc($result)) {
									echo '<div class="panel panel-default">
											<div class="panel-heading">
												<h4 class="panel-title"><a href="category-products.php?category_id='.$row['category_id'].'&page=1">'.$row['category_name'].'</a></h4>
											</div>
										</div>';
								}
							  ?>
							
	
						</div><!--/category-products-->
					
						<div class="brands_products"><!--brands_products-->
							<h2>Tác giả</h2>
							<?php 
								echo '
								<div class="brands-name">
								<ul class="nav nav-pills nav-stacked">
								';
								$result = pg_query($conn,"SELECT author, COUNT(id) FROM book_info GROUP BY(author) ORDER BY COUNT(id) DESC limit 5");
								while ($row = pg_fetch_assoc($result)) {
									echo '<li><a href="author.php?author='.$row['author'].'"> <span class="pull-right">('.$row['count'].')</span>'.$row['author'].'</a></li>';
								}
								echo '
								</ul>
								</div>
								';
							 ?>
							
								
						</div><!--/brands_products-->
					
					</div>
				</div>
				
				<div class="col-sm-9 padding-right">
					<div class="features_items"><!--features_items-->
						<?php 
						$category_id = $_GET['category_id'];
						$baivietmoitrang=8;
						$sobai = $baivietmoitrang*$page;


						$tmp = pg_query($conn,"SELECT * FROM book_info WHERE category_id = '$category_id'");
						$tong = pg_num_rows($tmp);
						$tmp1 = pg_query($conn,"SELECT * FROM category WHERE category_id = '$category_id'");
						$row1=pg_fetch_assoc($tmp1);
						echo '<h2 class="title text-center">'.$row1['category_name'].'</h2>';
						// echo $tong;
						// echo $sobai;
						// echo "SELECT category_id, category_name, id, name, price, image FROM category natural join book_info WHERE category_id = '$category_id' ORDER BY created_at DESC  Limit $baivietmoitrang OFFSET $sobai;";
						$result = pg_query($conn,"SELECT category_id, category_name, id, name, price, image FROM category natural join book_info WHERE category_id = '$category_id' ORDER BY created_at DESC  Limit $baivietmoitrang OFFSET $sobai;");

						
						while ($row=pg_fetch_assoc($result)) {
							$name = $row['name'];
							$row['name'] = cutString($row['name'],25);
							echo '
						<div class="col-sm-3">
							<div class="product-image-wrapper">
								<div class="single-products">
									<a href="product-details.php?id='.$row['id'].'" >
									    <div class="productinfo text-center">
											<img src="'.$row['image'].'"  title = "'.$name.'"/>
											<h2>'.$row['price'].'</h2>
											<quote>'.$row['name'].'</quote>
											<a onclick="add_to_cart('.$row['id'].'); event.preventDefault();" href="" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
										</div>
									</a>	
								</div>
								
							</div>
						</div>

							';

						}
						?>

						<?php 
						echo '<ul class="pagination">';
							if($page!=0)    echo'<li><a href="category-products.php?category_id='.$category_id.'&page='.($page).'">&laquo;</a></li>';
							else	    	echo'<li><a href="category-products.php?category_id='.$category_id.'&page='.($page+1).'">&laquo;</a></li>';
							for ($i=0; $i < ($tong/$baivietmoitrang) ; $i++) {
							if($page==$i)
								echo '<li class="active"><a href="category-products.php?category_id='.$category_id.'&page='.($i+1).'">'.($i+1).'</a></li>';
							else
								echo '<li><a href="category-products.php?category_id='.$category_id.'&page='.($i+1).'">'.($i+1).'</a></li>';
							}
							if($page<(($tong/$baivietmoitrang)-1))	echo '<li><a href="category-products.php?category_id='.$category_id.'&page='.($page+2).'">&raquo;</a></li>';
							else	 	echo'<li><a href="category-products.php?category_id='.$category_id.'&page='.($page+1).'">&raquo;</a></li>';
						echo'</ul>';

						 ?>
					</div><!--features_items-->
				</div>
			</div>
		</div>
	</section>
	
  
    <script src="js/jquery.js"></script>
	<script src="js/price-range.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
    <script src="js/sweet-alert.js"></script>
    


</body>
</html>