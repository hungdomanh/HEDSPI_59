<!DOCTYPE html>
<?php 
	session_start();

 ?>
<html lang="en">
<?php 
	include 'function.php';
	// kết nối với postgre
	$conn = pg_connect("host=localhost port=5432 dbname=tiki user=postgres password=123456");
	// echo $conn;
?>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | E-Shopper</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/sweet-alert.css">

    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<?php include 'header.php'; ?>
	
	<section>
		<div class="container">
			<div class="row">
				<?php include 'menu.php' ?>
					
					<div class="features_items"><!--features_items-->
						<?php $author = $_GET['author']; 
							echo '<h2 class="title text-center">'.$author.'</h2>';
							$result = pg_query($conn,"SELECT author, id, image,price, name,category_name, category_id FROM book_info natural join category WHERE author='$author'");
							while ($row = pg_fetch_assoc($result)) {
							echo '
								<div class="col-sm-9 padding-right">
									<div class="product-details"><!--product-details-->
							';
								echo '
									<div class="col-sm-5">
									<div class="view-product">
								';
								echo '<a href="product-details.php?id='.$row['id'].'"><img src="'.$row['image'].'" alt="" /></a>';
								echo '
								</div>
							</div>
								';
								 echo '
              					<div class="col-sm-7">
                					<div class="product-information"><!--/product-information-->
              					';
              					echo '<a href="product-details.php?id='.$row['id'].'"><h2>'.$row['name'].'</h2></a>';
              					echo '
                 					 <a href="product-details.php?id='.$row['id'].'"><span>'.$row['price'].'</span></a>
					                  				';
					              echo '
					                  <p><b>Tác giả:</b> '.$row['author'].'</p>
					                  <a href="category-products.php?category_id='.$row['category_id'].'&page=1"><p><b>Thể loại:</b> '.$row['category_name'].'</p></a>
					                  ';
					              echo '<a onclick="add_to_cart('.$row['id'].'); event.preventDefault();" href="" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>';
					              echo '
					                </div><!--/product-information-->
					              </div>
					              '; 
							echo '
								</div><!--/product-details-->
								</div>
							';
						}
						 ?>
				</div>
			</div>
		</div>
	</section>
	
	
    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.scrollUp.min.js"></script>
	<script src="js/price-range.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
    <script src="js/sweet-alert.js"></script>
    
</body>
</html>