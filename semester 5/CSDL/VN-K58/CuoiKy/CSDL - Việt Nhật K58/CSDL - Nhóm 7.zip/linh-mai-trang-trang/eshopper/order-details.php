<!DOCTYPE html>
<?php 
	session_start();
	$conn = pg_connect("host=localhost port=5432 dbname=tiki user=postgres password=123456");
 ?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Order | E-Shopper</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/sweet-alert.css">

    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<?php include 'header.php'; ?>

	<section id="cart_items">
		<div class="container">
			<div class="breadcrumbs">
				<ol class="breadcrumb">
				  <!-- <li><a href="#">Home</a></li> -->
				  <?php
				  	$id = $_GET['id'];
				  	echo '<h4 class="active">Đơn hàng #'.$id.'</h4>'
				  ?>
				</ol>
			</div>
			<div class="table-responsive cart_info">
				<table class="table table-condensed">
					<thead>
						<tr class="cart_menu">
							<td class="image">Sách</td>
							<td class="description"></td>
							<td class="price">Giá</td>
							<td class="quantity">Số lượng</td>
							<td class="total">Số tiền</td>
							<td></td>
						</tr>
					</thead>
					<tbody>
						<?php
							$sql = "select * from order_info where order_id = '$id'";
							$result = pg_query($conn,$sql);
							$row = pg_fetch_assoc($result);
							$receiver = $row['receiver'];
							$address = $row['address'];
							$phone = $row['phone'];
							$city_id = $row['city'];
							$district_id = $row['district'];
							$status = $row['status'];
							$sql = "select * from city where id = '$city_id'";
							$result = pg_query($conn,$sql);
							$row = pg_fetch_assoc($result);
							$city = $row['ten'];

							$sql = "select * from district where id = '$district_id'";
							$result = pg_query($conn,$sql);
							$row = pg_fetch_assoc($result);
							$district = $row['ten'];
						?>

						<?php 
							$sum = 0;
							if ($status==1)
								$sql = "select * from order_item where order_id = '$id'";
							else
								$sql = "select * from order_item_deleted where order_id = '$id'";
							$result = pg_query($conn,$sql);
							while ($item=pg_fetch_assoc($result)) {
								$key = $item["item_id"];
								$value = $item["quantity"];
								$tmp = "select image, name, id, price from book_info where id = '$key'";
								$result = pg_query($conn,$tmp);
								$row = pg_fetch_assoc($result);

								echo '<tr>
										<td class="cart_product">
											<a href="product-details.php?id='.$row['id'].'"><img src="'.$row['image'].'" alt=""></a>
										</td>
										<td class="cart_description">
											<h4><a href="product-details.php?id='.$row['id'].'">'.$row['name'].'</a></h4>
										</td>
										<td class="cart_price">
											<p>'.$row['price'].'</p>
										</td>
										<td class="cart_price">
											<p>'.$value.'</p>
										</td>
										<td class="cart_total">
											<p class="cart_total_price">'.$row['price']*$value.'.000 đ</p>
										</td>
									</tr>';
									$sum += $row['price']*$value;
							}
						 ?>
						
					</tbody>
				</table>
			</div>
		</div>
	</section> <!--/#cart_items-->

	<section id="do_action">
		<div class="container">
			<div class="heading">
				<h3>Thông tin giỏ hàng</h3>
			</div>
			<div class="row">
				<div class="col-sm-6">
					<div class="total_area">
						<?php 
							echo '
								<ul>
									<li>Tổng tiền các sản phẩm: <span>'.$sum.'.000 đ</span></li>
									<li>Thuế: <span>0đ</span></li>
									<li>Phí dịch vụ: <span>Free</span></li>
									<li>Tổng tiền: <span>'.$sum.'.000 đ</span></li>
								</ul>
							';
						 ?>
<!-- 							<a class="btn btn-default check_out" href="index.php">Tiếp tục mua sắm</a>
							<a class="btn btn-default check_out" href="checkout.php">Check out</a>
 -->					</div>
				</div>

				<div class="col-sm-6">
					<div class="total_area">

						<?php 
							

							echo '
								<ul>
									<li>Người nhận: <span>'.$receiver.'</span></li>
									<li>Địa chỉ: <span>'.$address.'</span></li>
									<li>Quận:<span>'.$district.'</span></li>
									<li>Thành phố: <span>'.$city.'</span> </li>
									<li>Số điện thoại: <span>'.$phone.'</span></li>
								</ul>
							';
						 ?>
<!-- 							<a class="btn btn-default check_out" href="index.php">Tiếp tục mua sắm</a>
							<a class="btn btn-default check_out" href="checkout.php">Check out</a>
 -->					</div>
				</div>
			</div>
		</div>
		<center>
		<?php
		echo'<a class="btn btn-default check_out" href="index.php">OK</a>';
		if ($status==1)
			echo' <a class="btn btn-default check_out" onclick="deleted_order('.$id.');">Hủy đơn hàng</a>';
		?>
		</center>	

	</section><!--/#do_action-->

	
    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
    <script src="js/sweet-alert.js"></script>

</body>
</html>