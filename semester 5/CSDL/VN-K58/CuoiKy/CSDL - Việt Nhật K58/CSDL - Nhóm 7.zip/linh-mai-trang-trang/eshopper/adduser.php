<?php 
	$conn = pg_connect("host=localhost port=5432 dbname=tiki user=postgres password=123456");

	date_default_timezone_set('Asia/Ho_Chi_Minh');
	$created_at=date('Y-m-d');

	$name = $_POST['name'];
	$email = $_POST['email'];
	$pass = $_POST['pass'];
	$passconfirm = $_POST['passconfirm'];

	if($_POST['name']==null)
		echo "name";
	else if ($_POST['email']==null)
		echo "email";
	else if (!filter_var($email, FILTER_VALIDATE_EMAIL))
		echo "email_error";
	else if(checkmail($email) != 0)
		echo "email_exits";
	else if($_POST['pass']==null)
		echo "pass";
	else if (strlen($pass) < 7)
		echo 'pass_short';
	else if($_POST['passconfirm']==null)
		echo "passconfirm";
	else if($pass != $passconfirm)
		echo "pass_error";
	else{
		$tmp = "INSERT INTO user_info(user_name,user_pass,user_email,user_created) VALUES ('$name','$pass','$email','$created_at')";
		$insert_data = pg_query($conn,$tmp);
		echo "success";
	}
	
	
	function checkmail($emailDB){
		$conn = pg_connect("host=localhost port=5432 dbname=tiki user=postgres password=123456");
		   $tmp = "select user_id from user_info where user_email = '$emailDB'";
		   $result = pg_query($conn,$tmp);
		   return pg_num_rows($result);
	}
 ?>