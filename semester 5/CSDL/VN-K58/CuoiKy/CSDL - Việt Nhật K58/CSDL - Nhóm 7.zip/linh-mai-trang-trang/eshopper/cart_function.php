<?php 
	session_start();
	if(empty($_SESSION['cart'])){
		$_SESSION['cart'] = array();
 	}

 	if(isset($_POST['add_item'])){
 		echo add_item($_POST['add_item']);
 	}
 	else if(isset($_POST['add_cart']))
 		add_cart($_POST['add_cart']);
 	else if(isset($_POST['minus_cart']))
 		minus_cart($_POST['minus_cart']);
 	else if(isset($_POST['remove_cart']))
 		remove_cart($_POST['remove_cart']);

 	function remove_cart($key){
 		unset($_SESSION['cart'][$key]);
 	}
 	function add_cart($key){
 		$conn = pg_connect("host=localhost port=5432 dbname=tiki user=postgres password=123456");
 		$tmp = "SELECT quantity_in FROM book_info Where id = '$key' ";
		$result = pg_query($conn,$tmp);
		$row = pg_fetch_row($result);
		if ($row[0] > $_SESSION['cart'][$key]){
 			$_SESSION['cart'][$key]++;
 		}
				else echo "error";
 	}
 	function minus_cart($key){
 		if($_SESSION['cart'][$key]>1)
	 		$_SESSION['cart'][$key]--;
	 	else
	 		unset($_SESSION['cart'][$key]);
 	}
 	function add_item($key){
 		$conn = pg_connect("host=localhost port=5432 dbname=tiki user=postgres password=123456");
 		$tmp = "SELECT quantity_in,name FROM book_info Where id = '$key' ";
		$result = pg_query($conn,$tmp);
		$row = pg_fetch_assoc($result);
		
	 		if(!array_key_exists($key, $_SESSION['cart'])){
				if($row['quantity_in']==0)
					echo "error";
				else{
					$_SESSION['cart'][$key] = 1;
				  	return $row['name'];
				}
				
	 		}else{
	 			if ($row['quantity_in'] > $_SESSION['cart'][$key]){
		 			$_SESSION['cart'][$key] ++;
					 return $row['name'];
		 		}
				else echo "error";
			}
	 		
		
 	}
 ?>