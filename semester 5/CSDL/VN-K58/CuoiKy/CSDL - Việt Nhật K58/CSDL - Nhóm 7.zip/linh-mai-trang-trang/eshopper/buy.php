<?php 
	session_start();
	$city =  $_POST['city'];
	$district = isset($_POST['district'])? $_POST['district'] : 0;
	// echo $district;
	$address = $_POST['address'];
	// echo $address;
	$receiver = $_POST['receiver'];
	$phone = $_POST['phone'];
	$total = $_SESSION['sum'];
	if(empty($_SESSION['cart'])){
		echo "null";
 	}
 	else if(!isset($_SESSION['login']))
 		echo "login";
 	else if($_POST['city']=="-----")
 		echo "city";
 	else if($_POST['district']=="0")
 		echo "district";
 	else if($_POST['address']==null)
 		echo "address";
 	else if($_POST['receiver']==null)
 		echo "receiver";
 	else if($_POST['phone']==null)
 		echo "phone";
 	else
 		{
 			$id = $_SESSION['login'];
 			$conn = pg_connect("host=localhost port=5432 dbname=tiki user=postgres password=123456");

 			date_default_timezone_set('Asia/Ho_Chi_Minh');
			$created_at=date('Y-m-d');
 			
 			$id = $_SESSION['login'];
 			$conn = pg_connect("host=localhost port=5432 dbname=tiki user=postgres password=123456");

 			date_default_timezone_set('Asia/Ho_Chi_Minh');
			$created_at=date('Y-m-d');
 			$check = true;

			foreach ($_SESSION['cart'] as $key => $value) {
				$tmp = "SELECT quantity_in, name FROM book_info Where id = '$key' ";
				$result = pg_query($conn,$tmp);
				$row = pg_fetch_row($result);
				if ($row[0] < $value){
					echo "error|".$row[1]."|".$row[0];
					$check = false;
					break;
				}
			}

 			if ($check){
	 			$tmp = "INSERT INTO order_info(user_id, order_created, city, district, address, receiver, phone,status,total) VALUES ('$id','$created_at','$city','$district','$address','$receiver','$phone',1,'$total')";
				$insert = pg_query($conn,$tmp);

				$tmp1 = "select order_id from order_info order by order_id desc limit 1";
				$result = pg_query($conn,$tmp1);
				$row = pg_fetch_assoc($result);

				$order_id = $row['order_id'];
				foreach ($_SESSION['cart'] as $key => $value) {
						$tmp2 = "INSERT INTO order_item(order_id, item_id, quantity) VALUES ('$order_id','$key', '$value')";
						$insert_data = pg_query($conn,$tmp2);
				}
				unset($_SESSION['cart']);
				echo $order_id;
			}
 		}

 ?>