<!DOCTYPE html>
<?php 
	session_start();

 ?>
<html lang="en">

<?php 
	include 'function.php';
	// kết nối với postgre
	$conn = pg_connect("host=localhost port=5432 dbname=tiki user=postgres password=123456");
	// echo $conn;
?>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | E-Shopper</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/sweet-alert.css">

    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<?php include 'header.php'; ?>
		<section>
		<div class="container">
			<div class="row">
				<?php include 'menu.php' ?>
				
				<div class="col-sm-9 padding-right">
					<div class="features_items"><!--features_items-->

						<h2 class="title text-center">Hài hước - Truyện cười</h2>
						<?php 
							// $result = pg_query($conn,"SELECT * FROM book_info WHERE category_id = 1");
							$sql = "SELECT * FROM book_info WHERE category_id = 1 ORDER BY created_at DESC Limit 8";
						 	
						 	$result = pg_query($conn,$sql);
						while ($row=pg_fetch_assoc($result)) {
							$name = $row['name'];
							$row['name'] = cutString($row['name'],25);
							echo '

						<div class="col-sm-3">
						
							<div class="product-image-wrapper">
							
								<div class="single-products">
								
								<a href="product-details.php?id='.$row['id'].'" >
									    <div class="productinfo text-center">

											<img src="'.$row['image'].'" title = "'.$name.'"/>
											<h2>'.$row['price'].'</h2>
											
											<quote>'.$row['name'].'</quote>

											<a onclick="add_to_cart('.$row['id'].');event.preventDefault();" href="" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
										</div>
								</a>
										
								</div>
								
							</div>
							
						</div>
						
							';
						}
						 ?>
						
					</div><!--features_items-->
					<div class="category-tab"><!--category-tab-->
					<div class="features_items"><!--features_items-->
						<h2 class="title text-center">Mới nhất</h2>
						<div class="col-sm-12">
							<ul class="nav nav-tabs">
								<?php 
									$sql = "SELECT * FROM category WHERE category_id = 1";
						 			$result = pg_query($conn,$sql);
						 			$row=pg_fetch_assoc($result);
						 			$id1 = utf8tourl($row['category_name']);
						 			echo '<li class="active"><a href="#'.$id1.'" data-toggle="tab">'.$row['category_name'].'</a></li>';
								 
						 			$sql1 = "SELECT * FROM category WHERE category_id >1 AND category_id <6 ";
						 			$result1 = pg_query($conn,$sql1);
						 			while ($row1=pg_fetch_assoc($result1)) {
						 				$id = utf8tourl($row1['category_name']);
						 				echo '<li><a href="#'.$id.'" data-toggle="tab">'.$row1['category_name'].'</a></li>';
						 				// echo $id;
						 			}
						 			
								 ?>
								
							</ul>
						</div>
						
						<div class="tab-content">
							<?php 
							echo '<div class="tab-pane fade active in" id="'.$id1.'" >';
								$category_id = $row['category_id'];
								$sql_info = "SELECT image, name, price, created_at, id FROM book_info WHERE category_id = $category_id ORDER BY created_at DESC limit 4";
						 		$result_info = pg_query($conn,$sql_info);
						 		while ($row_info=pg_fetch_assoc($result_info)) {
						 			echo '
								 		<div class="col-sm-3">
											<div class="product-image-wrapper">
												<div class="single-products">
													<a href="product-details.php?id='.$row_info['id'].'"><div class="productinfo 		text-center">
														<img src="'.$row_info['image'].'" alt="" />
														<h2>'.$row_info['price'].'</h2>
														<p>'.$row_info['name'].'</p>
														<a onclick="add_to_cart('.$row_info['id'].'); event.preventDefault();" href="" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
													</div>
													</a>
												</div>
											</div>
										</div>
						 			';
						 		}
						 	echo '</div>';
							 ?>

							 <?php 
								$sql1 = "SELECT * FROM category WHERE category_id >1 AND category_id <6 ";
						 		$result1 = pg_query($conn,$sql1);
								while ($row1=pg_fetch_assoc($result1)) {
									$id1 = utf8tourl($row1['category_name']);
 									// echo $id1;

						 			$category_id1 = $row1['category_id'];
						 			// echo $category_id1;
						 			echo '<div class="tab-pane fade" id="'.$id1.'" >';
						 				$sql_info1 = "SELECT image, name, price, created_at, id FROM book_info WHERE category_id = $category_id1 ORDER BY created_at DESC limit 4";
						 				$result_info1 = pg_query($conn,$sql_info1);
						 				while ($row_info1=pg_fetch_assoc($result_info1)) {
						 					echo '
										 		<div class="col-sm-3">
													<div class="product-image-wrapper">
														<div class="single-products">
															<a href="product-details.php?id='.$row_info1['id'].'"><div class="productinfo text-center">
																<img src="'.$row_info1['image'].'" alt="" />
																<h2>'.$row_info1['price'].'</h2>
																<p>'.$row_info1['name'].'</p>
																<a onclick="add_to_cart('.$row_info1['id'].'); event.preventDefault();" href="" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
															</div></a>
															
														</div>
													</div>
												</div>
						 					';
						 				}
						 				
						 			echo '</div>';
						 			}
							 ?>
							
							
						</div>
					</div><!--/category-tab-->
					
					<div class="recommended_items"><!--recommended_items-->
						<h2 class="title text-center">Tác phẩm được xem nhiều nhất</h2>
						
						<div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">

							<div class="carousel-inner">
								<div class="item active">	
									<?php 
										
										$sql = "SELECT image,price,name,id FROM book_info ORDER BY view DESC Limit 3 OFFSET 0";
						 	
						 				$result = pg_query($conn,$sql);
										while ($row=pg_fetch_assoc($result))
											echo '
											<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
											<a href="product-details.php?id='.$row['id'].'">
												<div class="productinfo text-center">
													<img src="'.$row['image'].'" alt="" />
													<h2>'.$row['price'].'</h2>
													<p>'.$row['name'].'</p>
													<a onclick="add_to_cart('.$row['id'].'); event.preventDefault();" href="" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
												</div>
											</a>	
											</div>
										</div>
									</div>
										';
									 ?>
									
									
								</div>
								<div class="item">	
									<?php 
										
										$sql = "SELECT image,price,name,id FROM book_info ORDER BY view DESC Limit 3 OFFSET 3";
						 				
						 				$result = pg_query($conn,$sql);
										while ($row=pg_fetch_assoc($result))
											echo '
											<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
											<a href="product-details.php?id='.$row['id'].'">
												<div class="productinfo text-center">
													<img src="'.$row['image'].'" alt="" />
													<h2>'.$row['price'].'</h2>
													<p>'.$row['name'].'</p>
													<a onclick="add_to_cart('.$row['id'].'); event.preventDefault();" href="" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
												</div>
											</a>
											</div>
										</div>
									</div>
										';
									 ?>
									
								</div>
								<div class="item">	
									<?php 
										
										$sql = "SELECT image,price,name,id FROM book_info ORDER BY view DESC Limit 3 OFFSET 6";
						 	
						 				$result = pg_query($conn,$sql);
										while ($row=pg_fetch_assoc($result))
											echo '
											<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
											<a href="product-details.php?id='.$row['id'].'">
												<div class="productinfo text-center">
													<img src="'.$row['image'].'" alt="" />
													<h2>'.$row['price'].'</h2>
													<p>'.$row['name'].'</p>
													<a onclick="add_to_cart('.$row['id'].'); event.preventDefault();" href="" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
												</div>
											</a>
											</div>
										</div>
									</div>
										';
									 ?>
									
								</div>
							</div>
							 <a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
								<i class="fa fa-angle-left"></i>
							  </a>
							  <a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
								<i class="fa fa-angle-right"></i>
							  </a>			
						</div>
					</div><!--/recommended_items-->
					
				</div>
			</div>
		</div>
	</section>
	
  
    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.scrollUp.min.js"></script>
	<script src="js/price-range.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
    <script src="js/sweet-alert.js"></script>

</body>
</html>