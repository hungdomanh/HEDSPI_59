				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Danh mục</h2>
						<div class="panel-group category-products" id="accordian">
							<?php
								$result = pg_query($conn,"SELECT * FROM category");
								while ($row = pg_fetch_assoc($result)) {
									echo '<div class="panel panel-default">
											<div class="panel-heading">
												
												<h4 class="panel-title"><a href="category-products.php?category_id='.$row['category_id'].'&page=1">'.$row['category_name'].'</a></h4>
												
											</div>
										</div>';
								}
							  ?>
							
	
						</div><!--/category-products-->
					
						<div class="brands_products"><!--brands_products-->
							<h2>Tác giả</h2>
							<?php 
								echo '
								<div class="brands-name">
								<ul class="nav nav-pills nav-stacked">
								';
								$result = pg_query($conn,"SELECT author, COUNT(id) FROM book_info GROUP BY(author) ORDER BY COUNT(id) DESC limit 5");
								while ($row = pg_fetch_assoc($result)) {
									// $tacgia = utf8tourl($row['author']);
									echo '<li><a href="author.php?author='.$row['author'].'"> <span class="pull-right">('.$row['count'].')</span>'.$row['author'].'</a></li>';
								}
								echo '
								</ul>
								</div>
								';
							 ?>
							
								
						</div><!--/brands_products-->
					
					</div>
				</div>