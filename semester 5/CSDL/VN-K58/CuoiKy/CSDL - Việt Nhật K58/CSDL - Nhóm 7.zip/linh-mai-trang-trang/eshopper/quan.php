<?php 
	$conn = pg_connect("host=localhost port=5432 dbname=tiki user=postgres password=123456");

	$cityId = isset($_POST['cityId']) ? $_POST['cityId'] : 0;

	$command = isset($_POST['get']) ? $_POST['get'] : "";

	switch ($command) {
		case 'city':
			$statement = "SELECT id, ten FROM city";
			break;
			
		case 'district':
			$statement = "SELECT id, ten FROM district WHERE id_city='$cityId'";
			break;

		default:
			break;
	}
	$result = pg_query($conn,$statement);

	echo json_encode(pg_fetch_all($result));
	exit();
 ?>