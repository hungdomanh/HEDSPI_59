<!DOCTYPE html>
<?php 
	session_start();
	$conn = pg_connect("host=localhost port=5432 dbname=tiki user=postgres password=123456");
 ?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Cart | E-Shopper</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/sweet-alert.css">

    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<?php include 'header.php'; ?>

	<section id="cart_items">
		<div class="container">
			<div class="breadcrumbs">
				<ol class="breadcrumb">
				  <!-- <li><a href="#">Home</a></li> -->
				  <h4 class="active">Shopping Cart</h4>
				</ol>
			</div>
			<div class="table-responsive cart_info">
				<table class="table table-condensed">
					<thead>
						<tr class="cart_menu">
							<td class="image">Sách</td>
							<td class="description"></td>
							<td class="price">Giá</td>
							<td class="quantity">Số lượng</td>
							<td class="total">Số tiền</td>
							<td></td>
						</tr>
					</thead>
					<tbody>
						<?php 
							$sum = 0;
							foreach ($_SESSION['cart'] as $key => $value) {
								$tmp = "select image, name, id, price from book_info where id = '$key'";
											$result = pg_query($conn,$tmp);
											$row = pg_fetch_assoc($result);
								echo '<tr>
										<td class="cart_product">
											<a href="product-details.php?id='.$row['id'].'"><img src="'.$row['image'].'" alt=""></a>
										</td>
										<td class="cart_description">
											<h4><a href="product-details.php?id='.$row['id'].'">'.$row['name'].'</a></h4>
										</td>
										<td class="cart_price">
											<p>'.$row['price'].'</p>
										</td>
										<td class="cart_quantity">
											<div class="cart_quantity_button">
												<a class="cart_quantity_up" onclick = "add_quantity('.$key.');event.preventDefault();" href=""> + </a>
												<input class="cart_quantity_input" type="text" name="quantity" value="'.$value.'" autocomplete="off" size="2">
												<a class="cart_quantity_down" onclick = "minus_quantity('.$key.');" href=""> - </a>
											</div>
										</td>
										<td class="cart_total">
											<p class="cart_total_price">'.$row['price']*$value.'.000 đ</p>
										</td>
										<td class="cart_delete">
											<a class="cart_quantity_delete" href="" onclick="remove_cart('.$key.')"><i class="fa fa-times"></i></a>
										</td>
									</tr>';
									$sum += $row['price']*$value;
							}
							$_SESSION['sum'] = $sum;
						 ?>
						
					</tbody>
				</table>
				<center><a href="index.php" style = "font-size: 20px">Tiếp tục mua sắm</a></center>
			</div>
		</div>
	</section> <!--/#cart_items-->

	<section id="do_action">
		<div class="container">
			<div class="heading">
				<h3>Thông tin giỏ hàng</h3>
			</div>
			<div class="row">
				
				<div class="col-sm-6">
					<div class="total_area">
						<?php 
							echo '
								<ul>
									<li>Tổng tiền các sản phẩm: <span>'.$sum.'.000 đ</span></li>
									<li>Thuế: <span>0đ</span></li>
									<li>Phí dịch vụ: <span>Free</span></li>
									<li>Tổng tiền: <span>'.$sum.'.000 đ</span></li>
								</ul>
							';
						 ?>
							<a class="btn btn-default check_out" href="index.php">Tiếp tục mua sắm</a>
							<a class="btn btn-default check_out" href="checkout.php">Check out</a>
					</div>
				</div>
			</div>
		</div>
	</section><!--/#do_action-->

	
    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
    <script src="js/sweet-alert.js"></script>

</body>
</html>