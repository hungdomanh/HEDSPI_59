def make_diem(mon,n)
	x=Time.now
	name=mon+".csv"
    	f=File.open(name,"w")
    	n.times do |x|
      		f.write "#{x},#{0.25*rand(40)}\n"
    	end
    	f.close
    	y=Time.now
    	puts "#{y.min-x.min} minutes to finish ."
end
make_diem("toan",1000000)