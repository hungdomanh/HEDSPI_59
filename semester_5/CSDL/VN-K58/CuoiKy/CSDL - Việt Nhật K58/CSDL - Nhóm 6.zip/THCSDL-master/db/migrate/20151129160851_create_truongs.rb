class CreateTruongs < ActiveRecord::Migration
  def change
    create_table :truongs do |t|
      t.string :ten
      t.string :diachi
      t.string :website
      t.references :user, index: true, foreign_key: true

      t.timestamps null: false
    end
  end
end
