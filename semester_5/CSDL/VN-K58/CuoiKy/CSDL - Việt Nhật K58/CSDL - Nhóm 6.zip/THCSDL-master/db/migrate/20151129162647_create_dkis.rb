class CreateDkis < ActiveRecord::Migration
  def change
    create_table :dkis do |t|
      t.references :hsinh, index: true, foreign_key: true
      t.references :truong, index: true, foreign_key: true
      t.references :khoa, index: true, foreign_key: true
      t.float :diem

      t.timestamps null: false
    end
  end
end
