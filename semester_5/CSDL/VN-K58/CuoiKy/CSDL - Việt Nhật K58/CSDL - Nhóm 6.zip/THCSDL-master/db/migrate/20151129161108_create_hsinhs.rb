class CreateHsinhs < ActiveRecord::Migration
  def change
    create_table :hsinhs do |t|
      t.string :sbd
      t.string :ten
      t.date :ngaysinh
      t.string :diachi
      t.references :user, index: true, foreign_key: true

      t.timestamps null: false
    end
  end
end
