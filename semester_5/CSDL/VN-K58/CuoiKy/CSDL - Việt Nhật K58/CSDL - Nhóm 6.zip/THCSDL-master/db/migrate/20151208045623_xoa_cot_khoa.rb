class XoaCotKhoa < ActiveRecord::Migration
  def change
  	remove_column :khoas, :created_at
  	remove_column :khoas, :updated_at
  	
  end
end
