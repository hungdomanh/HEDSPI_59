class CreateKhoas < ActiveRecord::Migration
  def change
    create_table :khoas do |t|
      t.string :ten
      t.integer :chitieu
      t.references :truong, index: true, foreign_key: true
      t.string :khoi

      t.timestamps null: false
    end
  end
end
