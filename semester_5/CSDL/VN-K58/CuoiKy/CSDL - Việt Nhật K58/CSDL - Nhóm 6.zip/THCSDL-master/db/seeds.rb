# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:

def rand_diem(mon,number)
	number.times do |n|
      		mon.create!(sbd: n,diem: 0.25*rand(40))
    	end
end
def rand_khoa(truong_id,number)
	khois=["A","A1","B","C","D"]
	number.times do |n|
		Khoa.create!(ten: Faker::Name.first_name ,chitieu: rand(10)*100,truong_id: truong_id,khoi: khois[rand(5)])
	end
end
#Dang ki ngau nhien 4 nguyen vong cho 1 hoc sinh co id da biet
def rand_dang_ki(hs)
	hs.dkis.destroy_all
	sum=Khoa.count
	i=1
	until i==4 do
		offset =rand(sum) 
		rand_kh = Khoa.offset(offset).first
		if rand_kh.hsinhs.find_by_id(hs.id)==nil
			Dki.create!(hsinh_id: hs.id,khoa_id: rand_kh.id,truong_id: rand_kh.truong.id,nguyenvong: i,diem: rand(30))
			i=i+1
		else
		end
	end
end
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)
#User.create!(name:  "Nguyen Dinh Hung",password: "123456",password_confirmation: "123456")
#Hsinh.destroy_all
#100000.times do |n|
#	ten=Faker::Name.name
#	sbd=50+n
#	ns=Faker::Date.between(18.years.ago, 30.years.ago)
#	diachi=Faker::Address.city
#	Hsinh.create!(ten: ten,sbd: sbd,ngaysinh: ns, diachi: diachi)
#end
#Hsinh.all.each do |hs|
#rand_diem(Toan,100000)
#rand_diem(Vatli,100000)
#rand_diem(Hoahoc,100000)
#rand_diem(Van,100000)
#rand_diem(Ngoaingu,100000)
#rand_diem(Sinh,100000)
#rand_diem(Su,100000)
#rand_diem(Diatli,100000)
#end
#Toan.destroy_all
##RAN DOM 15 KHOAS CHO TRUONG DAU TIEN
#rand_khoa(4,15)
##
@hsinhs=Hsinh.where("id<100").select(:id).all
i=0
@hsinhs.each do  |hs|
	user=User.create(name:  "test"+"#{i}",password: "123456",password_confirmation: "123456")
	hs.user_id=user.id
	rand_dang_ki(hs)
	i=i+1
end



