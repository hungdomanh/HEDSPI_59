class CreateKhois < ActiveRecord::Migration
  def change
    create_table :khois do |t|
      t.string :ten
      t.string :mon1
      t.string :mon2
      t.string :mon3

      t.timestamps null: false
    end
  end
end
