class RemoveFieldNameFromTableName < ActiveRecord::Migration
  def change
  	remove_column :toans, [:created_at, :updated_at]
  	remove_column :vatlis, [:created_at, :updated_at]
  	remove_column :hoahocs, [:created_at, :updated_at]
  	remove_column :vans, [:created_at, :updated_at]
  	remove_column :ngoaingus, [:created_at, :updated_at]
  	remove_column :sinhs, [:created_at, :updated_at]
  	remove_column :sus, [:created_at, :updated_at]
  	remove_column :dialis, [:created_at, :updated_at]
  end
end
