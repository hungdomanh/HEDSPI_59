class AddNguyenvongToDki < ActiveRecord::Migration
  def change
    add_column :dkis, :nguyenvong, :integer
  end
end
