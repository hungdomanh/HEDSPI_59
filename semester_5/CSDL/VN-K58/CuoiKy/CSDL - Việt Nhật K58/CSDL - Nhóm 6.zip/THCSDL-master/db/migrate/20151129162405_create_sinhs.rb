class CreateSinhs < ActiveRecord::Migration
  def change
    create_table :sinhs do |t|
      t.string :sbd
      t.float :diem

      t.timestamps null: false
    end
  end
end
