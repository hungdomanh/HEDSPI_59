class RemoveCreatedAtFromHsinh < ActiveRecord::Migration
  def change
  	remove_column :hsinhs, :created_at
  	remove_column :hsinhs, :updated_at
  	
  end
end
