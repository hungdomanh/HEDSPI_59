class AddDiemToKhoa < ActiveRecord::Migration
  def change
    add_column :khoas, :diem, :float
  end
end
