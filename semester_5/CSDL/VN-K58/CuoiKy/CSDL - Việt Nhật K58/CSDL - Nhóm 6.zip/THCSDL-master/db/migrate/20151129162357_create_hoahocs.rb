class CreateHoahocs < ActiveRecord::Migration
  def change
    create_table :hoahocs do |t|
      t.string :sbd
      t.float :diem

      t.timestamps null: false
    end
  end
end
