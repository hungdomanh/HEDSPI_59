class RemoveFieldNameFromTableName2 < ActiveRecord::Migration
  def change
  	remove_column :toans, :updated_at
  	remove_column :vatlis, :updated_at
  	remove_column :hoahocs, :updated_at
  	remove_column :vans, :updated_at
  	remove_column :ngoaingus, :updated_at
  	remove_column :sinhs,  :updated_at
  	remove_column :sus,  :updated_at
  	remove_column :dialis,  :updated_at
  end
end
