class CreateVatlis < ActiveRecord::Migration
  def change
    create_table :vatlis do |t|
      t.string :sbd
      t.float :diem

      t.timestamps null: false
    end
  end
end
