class DkisController < ApplicationController
  before_action :logged_in_user, only: [:new, :create, :edit, :update, :destroy]
  before_action :list_khoi, only: [:create, :update]
  before_action :is_hs ,only: [:new,:create,:destroy]
  before_action :correct_hs ,only: [:edit,:update]
  before_action :set_x, only: [:edit,:update,:show,:destroy]
  
	def index
		@xs=Dki.all
	end
	def new
              @x = Dki.new
              @trgs=Truong.select(:id,:ten).to_a
              if params[:truong_id]
                @selected=params[:truong_id]
                @khoas = Truong.find_by_id(params[:truong_id]).khoas.select(:id,:ten).to_a
              else
                @khoas = []
              end
      end
	def show
	end
	def edit
            @trgs=Truong.select(:id,:ten).to_a
            if params[:truong_id]
              @selected=params[:truong_id]
              @khoas = Khoa.where(:truong_id => params[:truong_id]).select(:id,:ten).to_a
            else
              @khoas = []
            end
	end
	def destroy
            @x.destroy
            flash[:success]='Đã xóa xong !.'
            redirect_to current_user.hsinh
      end
	def update
            if @x.update(x_params)&&@x.update(diem: tong_diem(@x))
              flash[:success]= "Thay đổi thành công ."
              redirect_to current_user.hsinh
            else
              flash[:danger]= "Thay đổi thất bại: Chưa có điểm/ có điểm liệt/ trùng nguyện vọng/ trùng khoa ??."
              redirect_to edit_dki_path
            end
      end
	def create
          @x=Dki.new(x_params)
          @x.hsinh_id=current_user.hsinh.id
          @x.diem=tong_diem(@x)
          if check
              if  @x.save
                  flash[:success]= "Đăng kí thành công ,xem kết quả trên giao diện ."
                  redirect_to current_user.hsinh
              else
                  flash[:danger]= "Thông tin không hợp lệ, đăng kí thất bại !"
                  redirect_to new_dki_path
              end
          else
                flash[:danger]= "Đăng kí thất bại: Chưa có điểm/ có điểm liệt/ trùng nguyện vọng/ trùng khoa ??."
                redirect_to new_dki_path
          end
	end
private
	def set_x
		@x=Dki.find_by_id(params[:id])
            sida_url @x
	end
	def x_params
              params.require(:dki).permit(:hsinh_id,:truong_id,:khoa_id,:nguyenvong)
      end
  
      def check
          tmp=current_user.hsinh.dkis
          tmp.find_by(nguyenvong: @x.nguyenvong)==nil&&tmp.find_by(khoa_id: @x.khoa_id)==nil
      end
      def tong_diem (dangki)
          khoi=dangki.khoa.khoi
          sbd=dangki.hsinh.sbd
          @diem=0
            @khois.each do |k|
              if k[:ten]==khoi
                  k[:mon].each do |i|
                      tmp=@lists[i].find_by_sbd(sbd)
                      if tmp
                        @diem+= tmp.diem
                      else
                        return -1
                      end
                  end
              end
            end
          return @diem
      end
      #Toan,Li,Hoa,Van,Ngoaingu,Sinh,Su,Dia<=>0,1,2,3,4,5,6,7
      def list_khoi
          @khois=[{:ten=>"A",:mon=>[0,1,2]},{:ten=>"A1",:mon=>[0,1,4]},{:ten=>"B",:mon=>[0,2,5]},{:ten=>"C",:mon=>[3,6,7]},{:ten=>"D",:mon=>[0,3,4]}]
          @lists=[Toan,Vatli,Hoahoc,Van,Ngoaingu,Sinh,Su,Diali]
      
      end
      def is_hs
          unless current_user.hsinh
            flash[:danger]="Chỉ học sinh mới có quyền đó !"
            redirect_to root_url
          end
      end
     def correct_hs
          @dki=Dki.find_by_id(params[:id])
          unless current_user.hsinh==@dki.hsinh
            flash[:danger]="Học sinh đó không phải là bạn, không thể chỉnh sửa !"
            redirect_to root_url
          end
     end
end
