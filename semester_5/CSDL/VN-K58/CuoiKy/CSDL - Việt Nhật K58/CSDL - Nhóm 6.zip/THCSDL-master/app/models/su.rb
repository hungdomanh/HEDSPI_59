class Su < ActiveRecord::Base
	require 'csv'
	validates :diem,presence:true, numericality: { greater_than_or_equal_to:0,less_than_or_equal_to:10}
	validates :sbd, presence:true, uniqueness:true
	def self.import(file)
	    CSV.foreach(file.path, headers: true) do |row|

	      x_hash = row.to_hash # .except("price")
	      xs = Su.where(sbd: x_hash["sbd"])

	      if xs.count == 1
	        xs.first.update_attributes(x_hash.except("id","created_at","updated_at"))
	      else
	        Su.create!(x_hash)
	      end # end if !product.nil?
	    end # end CSV.foreach
	  end # end self.im
end
