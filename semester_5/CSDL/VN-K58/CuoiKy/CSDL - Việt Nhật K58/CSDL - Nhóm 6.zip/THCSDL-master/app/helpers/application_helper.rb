module ApplicationHelper

  # Returns the full title on a per-page basis.
  def full_title(page_title = '')
    base_title = "Ho tro tuyen sinh quoc gia"
    if page_title.empty?
      base_title
    else
      page_title + " | " + base_title
    end
  end
  def dot1?
  	Time.now<Time.new(2015,9,20)
  end
 
end

