class Khoi < ActiveRecord::Base
end
