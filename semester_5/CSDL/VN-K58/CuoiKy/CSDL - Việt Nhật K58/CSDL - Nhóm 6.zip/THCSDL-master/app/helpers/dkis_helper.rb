module DkisHelper
	def set_diem (hsinh)
	   	@diems=[]
	   	@diems[0]=Toan.find_by_sbd(hsinh.sbd)
	   	@diems[1]=Vatli.find_by_sbd(hsinh.sbd)
	   	@diems[2]=Hoahoc.find_by_sbd(hsinh.sbd)
	   	@diems[3]=Van.find_by_sbd(hsinh.sbd)
	   	@diems[4]=Ngoaingu.find_by_sbd(hsinh.sbd)
	   	@diems[5]=Sinh.find_by_sbd(hsinh.sbd)
	   	@diems[6]=Su.find_by_sbd(hsinh.sbd)
	   	@diems[7]=Diali.find_by_sbd(hsinh.sbd)
	   	return @diems
	   end
end
