class Hsinh < ActiveRecord::Base
  
  require 'csv'
	has_many :dkis
	has_many :truongs,through: :dkis
	has_many :khoas,through: :dkis
	
	belongs_to :user
	validates :ten ,:sbd, presence:true,length:{maximum:30}
	validates :sbd,uniqueness:true
	def self.import(file)
	    CSV.foreach(file.path, headers: true) do |row|

	      hsinh_hash = row.to_hash # .except("price")
	      hs = Hsinh.where(sbd: hsinh_hash["sbd"])

	      if hs.count == 1
	        hs.first.update_attributes(hsinh_hash.except("id","created_at","updated_at"))
	      else
	        Hsinh.create!(hsinh_hash)
	      end # end if !product.nil?
	    end # end CSV.foreach
	end # end self.im
	  
end
