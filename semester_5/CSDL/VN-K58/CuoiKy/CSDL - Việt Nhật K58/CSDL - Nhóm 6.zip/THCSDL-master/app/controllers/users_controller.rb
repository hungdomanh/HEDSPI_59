class UsersController < ApplicationController
	 before_action :logged_in_user, only: [:index, :edit, :update, :destroy]
	 before_action :correct_user,   only: [:edit, :update]
	 before_action :admin_user,     only: [:new,:create,:destroy]
	 before_action :find_oj,     only: :create
	def index
	       @users = User.paginate(page: params[:page], :per_page=>15)
	end
	def show
		@user = User.find_by_id(params[:id])
		if @user ==nil
			redirect_to sida_path
		else
		
			if @user.id!=1
				@x=@user.hsinh||@user.truong
			else 
				@x=nil
			end
		 	@microposts = @user.microposts.paginate(page: params[:page], :per_page=>5)
			if logged_in?
			      @micropost  = current_user.microposts.build
			end
		end
	end
	
	def new
		@user = User.new
	end
	
	def create
		@user = User.new(user_params)
	    	if @oj!=nil && @oj.user_id==nil &&@user.save
		      @oj.update_attribute(:user_id, @user.id)
		      flash[:info] = "Account created."
		      redirect_to users_path
	    	else
	    		flash.now[:danger]="Incorrect Infomation!"
	    		render 'new'
	    	end
	end
	def edit
	    @user = User.find_by_id(params[:id])
	end
	def update
		@user = User.find_by_id(params[:id])
    		if @user.update_attributes(user_params)
	            		flash[:success] = "Profile updated"
	      		redirect_to @user
    		else
      			render 'edit'
    		end
  	end

	def destroy
		@x=User.find_by_id(params[:id])
		if @x.hsinh!=nil
		      @x.hsinh.update_attribute(:user_id,nil)
		elsif @x.truong!=nil
		      @x.truong.update_attribute(:user_id,nil)
		end
		@x.destroy
		flash[:success] = "User deleted"
		redirect_to users_url
	end

	private

	    def user_params
	      	params.require(:user).permit(:name, :password,
	                                   :password_confirmation)
	    end
	   
	# Confirms the correct user.
	def correct_user
	      @user = User.find_by_id(params[:id])
	      unless current_user?(@user)
	      	flash[:danger]="Bạn không phải user đó !"
	      	redirect_to(root_url) 
	      end
	end
	
	#Tao moi tai khoan truong hoac hoc sinh
	  def find_oj
	    if params[:loai_tai_khoan]=='1'
	      @oj=Truong.find_by(id: params[:so_id])
	    elsif params[:loai_tai_khoan]=='0'
	      @oj=Hsinh.find_by(sbd: params[:so_id])
	    end
	    @oj
	  end
end
