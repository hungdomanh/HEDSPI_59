class Truong < ActiveRecord::Base
  
  require 'csv'
	has_many :khoas, dependent: :destroy
	has_many :dkis 
	has_many :hsinhs,through: :dkis
	belongs_to :user
	validates :ten ,presence:true, uniqueness:true, length:{maximum:50}
	validates :diachi, length:{maximum:50}
	def self.import(file)
	    CSV.foreach(file.path, headers: true) do |row|

	      trg_hash = row.to_hash # .except("price")
	      trgs = Truong.where(ten: trg_hash["ten"])

	      if trgs.count == 1
	        trgs.first.update_attributes(trg_hash.except("id","user_id","created_at","updated_at"))
	      else
	        Truong.create!(trg_hash)
	      end # end if !product.nil?
	    end # end CSV.foreach
	  end # end self.im
  def self.as_csv
  	CSV.generate do |csv|
	      csv << column_names
	      all.each do |item|
	        csv << item.attributes.values_at(*column_names)
	      end
	    end
  end
end
