class KhoasController < ApplicationController
	before_action :logged_in_user, only: [:new, :create, :edit, :update, :destroy]
	before_action :is_truong, only: [:new, :create]
	before_action :correct_khoa,   only: [ :edit, :update, :destroy]
	before_action :set_kh, only: [:edit,:update,:show,:destroy]
	
	def new
		@kh = Khoa.new
	end
	def show
		@dangkis=@kh.dkis.order(diem: :desc).paginate(page: params[:page],:per_page=>10)
	end
	def edit
	end
	def destroy
	    @kh.destroy
	    flash[:info]= 'Đã xóa .'
	    redirect_to current_user.truong 
	end
	def update
		if @kh.ten!=kh_params[:ten]
			if current_user.truong.khoas.find_by_ten(kh_params[:ten])!=nil
				flash[:danger]= 'Khoa này đã tồn tại .'
			        	redirect_to edit_khoa_path
			else
				if @kh.update_attributes(ten:kh_params[:ten],chitieu:kh_params[:chitieu],khoi:kh_params[:khoi],diem:kh_params[:diem])
					flash[:success]= 'Cập nhật thành công .'
					redirect_to @kh
				end
			end
	    	else
		      	if @kh.update_attributes(ten:kh_params[:ten],chitieu:kh_params[:chitieu],khoi:kh_params[:khoi],diem:kh_params[:diem])
			        flash[:success]= 'Cập nhật thành công .'
			        redirect_to @kh
			    else
			      	flash[:danger]= 'Đã có lỗi xảy ra !.'
			        	redirect_to edit_khoa_path
			end
		end
	end
	
	def create
		@kh=Khoa.new(kh_params)
		@kh.truong_id=current_user.truong.id
		if !current_user.truong.khoas.find_by_ten(@kh.ten) && @kh.save
		         flash[:success]= 'Tạo thành công .'
		         redirect_to @kh
		else
		      render 'new'
		end
	   
	end
private
	def set_kh
		@kh=Khoa.find_by_id(params[:id])
		sida_url @kh
	end
	def kh_params
	      params.require(:khoa).permit(:ten,:chitieu,:khoi,:diem)
	end
	
	# Confirms a correct_truong.
	    def correct_khoa
	    	@kh = Khoa.find_by_id(params[:id])
	      unless current_user.truong==@kh.truong
	        flash[:danger] = "Đó không phải khoa,viện của trường bạn !."
	        redirect_to current_user.truong
	      end
	    end
	    # Confirms a logged-in user.
	    def is_truong
	           	unless current_user.truong
	          		flash[:danger] = "Bạn không có quyền này !"
	        		redirect_to current_user
	      	end
	    end
    
end
