module KhoasHelper
end
