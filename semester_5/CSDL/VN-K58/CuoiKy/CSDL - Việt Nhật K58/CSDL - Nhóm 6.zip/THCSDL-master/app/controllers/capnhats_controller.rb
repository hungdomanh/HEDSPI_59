class CapnhatsController < ApplicationController
  before_action :is_admin
  before_action :set_l, only: [:thongke,:thongke1]
  def index
  end
  def toan
      begin
        Toan.import(params[:file])
        flash[:success] = "Đã cập nhật thành công môn Toán ."
        redirect_to capnhats_path
      rescue
        flash[:danger] = "File CSV không đúng ."
        redirect_to capnhats_path 
      end
  end

  def van
    begin
        Van.import(params[:file])
        flash[:success] = "Đã cập nhật thành công môn Văn ."
        redirect_to capnhats_path
      rescue
        flash[:danger] = "File CSV không đúng ."
        redirect_to capnhats_path 
      end
  end

  def nn
    begin
        Ngoaingu.import(params[:file])
        flash[:success] = "Đã cập nhật thành công môn Ngoại ngữ ."
        redirect_to capnhats_path
      rescue
        flash[:danger] = "File CSV không đúng ."
        redirect_to capnhats_path 
      end
  end

  def sinh
    begin
        Sinh.import(params[:file])
        flash[:success] = "Đã cập nhật thành công môn Sinh học ."
        redirect_to capnhats_path
      rescue
        flash[:danger] = "File CSV không đúng ."
        redirect_to capnhats_path 
      end
  end

  def su
    begin
        Su.import(params[:file])
        flash[:success] = "Đã cập nhật thành công môn Lịch sử ."
        redirect_to capnhats_path
      rescue
        flash[:danger] = "File CSV không đúng ."
        redirect_to capnhats_path 
      end
  end

  def hoa
    begin
        Hoahoc.import(params[:file])
        flash[:success] = "Đã cập nhật thành công môn Hóa học ."
        redirect_to capnhats_path
      rescue
        flash[:danger] = "File CSV không đúng ."
        redirect_to capnhats_path 
      end
  end

  def li
    begin
        Vatli.import(params[:file])
        flash[:success] = "Đã cập nhật thành công môn Vật lí ."
        redirect_to capnhats_path
      rescue
        flash[:danger] = "File CSV không đúng ."
        redirect_to capnhats_path 
      end
  end

  def dia
    begin
        Diali.import(params[:file])
        flash[:success] = "Đã cập nhật thành công môn Địa lí ."
        redirect_to capnhats_path
      rescue
        flash[:danger] = "File CSV không đúng ."
        redirect_to capnhats_path 
      end
  end
  def thongkefull
        @thong_kes=[]
        @lists.each do |m|
             @thong_kes<<{:ten=>m,:kq=>thong_ke_mon(m),:tong=>m.count}
        end
  end
  def thongke
    if params[:mon]!=nil
      mon= @lists[params[:mon].to_i]
      @tong=mon.count
      @kqs=thong_ke_mon(mon)
    else
      @kqs=[]
      @tong=nil
    end
  end
  private
    def is_admin
        if !logged_in?||current_user.id!=1
            flash[:danger]="Bạn không phải admin nên không có quyền đó !"
            redirect_to(root_url)
        end
    end
    def set_l
      @lists=[Toan,Vatli,Hoahoc,Van,Ngoaingu,Sinh,Su,Diali]
    end
    def thong_ke_mon(mon)
          mon.select(:diem).group(:diem).order(:diem).count.to_a
    end
end
