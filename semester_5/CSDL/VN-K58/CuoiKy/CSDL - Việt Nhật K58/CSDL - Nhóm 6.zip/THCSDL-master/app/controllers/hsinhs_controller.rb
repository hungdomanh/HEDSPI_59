class HsinhsController < ApplicationController
	before_action :logged_in_user, only: [:new, :create, :edit, :index,:update, :destroy]
      	before_action :admin_user, only: [:new, :create, :index ,:destroy,:import]
      	before_action :correct_hsinh,   only: [:edit, :update]
	before_action :set_x, only: [:edit,:update,:show,:destroy]
	
	def index
		tmp=params[:page]? params[:page].to_i : 1
		@count=50*tmp-49
		if params[:giatri]!=""
			@tim=params[:giatri].to_s
			case params[:loai]
			when '0'
				@xs= Hsinh.where(["ten LIKE ?","%#{@tim}%"]).paginate(page: tmp, :per_page => 50)
			when '1'
				@xs= Hsinh.where(["sbd LIKE ?","%#{@tim}%"]).paginate(page: tmp, :per_page => 50)
			when '2'
				@xs= Hsinh.where(["diachi LIKE ?","%#{@tim}%"]).paginate(page: tmp, :per_page => 50)
			else
			end
			
		else
			@xs= Hsinh.paginate(page: tmp, :per_page => 50)
		end
	end
	def xemdiem
		if sbd=params[:sbd]
			@x=Hsinh.find_by_sbd(sbd)
			if @x
				@diems=[]
			   	if x=Toan.find_by_sbd(sbd)
			   		@diems[0]=[x.diem, x.diem ? Toan.where("diem>?",x.diem).count+1 : nil]
			   	end
			   	if x=Vatli.find_by_sbd(sbd)
			   		@diems[1]=[x.diem,x.diem ? Vatli.where("diem>?",x.diem).count+1 : nil]
			   	end
			   	if x=Hoahoc.find_by_sbd(sbd)
			   		@diems[2]=[x.diem,x.diem ? Hoahoc.where("diem>?",x.diem).count+1 : nil]
			   	end
			   	if x=Van.find_by_sbd(sbd)
			   		@diems[3]=[x.diem,x.diem ? Van.where("diem>?",x.diem).count+1 : nil]
			   	end
			   	if x=Ngoaingu.find_by_sbd(sbd)
			   		@diems[4]=[x.diem,x.diem ? Ngoaingu.where("diem>?",x.diem).count+1 : nil]
			   	end
			   	if x=Sinh.find_by_sbd(sbd)
			   		@diems[5]=[x.diem,x.diem ? Sinh.where("diem>?",x.diem).count+1 : nil]
			   	end
			   	if x=Su.find_by_sbd(sbd)
			   		@diems[6]=[x.diem,x.diem ? Su.where("diem>?",x.diem).count+1 : nil]			   	
			   	end
			   	if x=Diali.find_by_sbd(sbd)
			   		@diems[7]=[x.diem,x.diem ? Diali.where("diem>?",x.diem).count+1 : nil]
			   	end
			else
				redirect_to sida_path
			end
		else
			@diems=[]
		end
	end
	def new
		@x = Hsinh.new
	end
	def show
		@ks=[]
		@dkis=@x.dkis.order :nguyenvong
		@dkis.each do |dk|
			hang=Dki.where("khoa_id=? AND diem>?",dk.khoa_id,dk.diem).count
			@ks<<hang
		end
	end
	def edit
	end
	def destroy
		if @x.user!=nil
		      @x.user.destroy
		end
		@x.destroy
		flash[:info]= 'Đã xóa .'
		redirect_to hsinhs_url
		end
	def update
	      if @x.update(x_params)
	      	flash[:info]='Đã cập nhật .'
	        	redirect_to @x
	      else
	       	render 'edit'
	      end
  	end
	def create
		@x=Hsinh.new(x_params)
	      	if @x.save
	      	flash[:success]= 'Tạo mới thành công .'
	        	redirect_to @x
	      	else
	        	render 'new'
	      	end
    	end
	
	def import
	    begin
	      Hsinh.import(params[:file])
	      flash[:success]= "File is imported."
	      redirect_to hsinhs_path
	    rescue
		flash[:danger]= "Invalid CSV file format."
		redirect_to hsinhs_path
	    end
	end
private
	def set_x
		@x=Hsinh.find_by_id(params[:id])
		if @x
			@diems=[]
		   	@diems[0]=Toan.find_by_sbd(@x.sbd)
		   	@diems[1]=Vatli.find_by_sbd(@x.sbd)
		   	@diems[2]=Hoahoc.find_by_sbd(@x.sbd)
		   	@diems[3]=Van.find_by_sbd(@x.sbd)
		   	@diems[4]=Ngoaingu.find_by_sbd(@x.sbd)
		   	@diems[5]=Sinh.find_by_sbd(@x.sbd)
		   	@diems[6]=Su.find_by_sbd(@x.sbd)
		   	@diems[7]=Diali.find_by_sbd(@x.sbd)
		else
			redirect_to sida_path
		end
	end
	def x_params
	      params.require(:hsinh).permit(:sbd,:ten,:ngaysinh,:diachi)
	end
	# Confirms the correct user.
	def correct_hsinh
	      @hs = Hsinh.find_by_id(params[:id])
	      unless current_user.hsinh==@hs
	      	flash[:danger]="Bạn không phải là học sinh đó !"
	      	redirect_to(root_url) 
	      end
	end

end
