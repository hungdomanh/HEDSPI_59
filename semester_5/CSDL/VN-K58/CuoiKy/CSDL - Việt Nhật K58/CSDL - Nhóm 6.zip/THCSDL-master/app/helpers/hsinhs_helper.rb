module HsinhsHelper
end
