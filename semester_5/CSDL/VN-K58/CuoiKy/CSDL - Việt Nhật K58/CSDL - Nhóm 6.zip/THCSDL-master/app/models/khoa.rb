class Khoa < ActiveRecord::Base
  belongs_to :truong
  	has_many :dkis, dependent: :destroy
	has_many :hsinhs,through: :dkis
	validates :ten,:khoi ,presence:true,length:{maximum:50}
	validates :chitieu, numericality: { only_integer: true,greater_than_or_equal_to:0}
	validates :diem, numericality: { greater_than_or_equal_to:10,less_than_or_equal_to:30},allow_blank: true
end
