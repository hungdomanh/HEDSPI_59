class TruongsController < ApplicationController
      before_action :logged_in_user, only: [:new, :create, :edit, :update, :destroy]
      before_action :admin_user, only: [:new, :create,:destroy,:import]
      before_action :correct_truong,   only: [ :edit, :update ]
	before_action :set_x, only: [:edit,:update,:show,:destroy]

  def index
    if params[:tentruong]!=nil
      @tim=params[:tentruong].to_s
    else
      @tim=" "
    end
      tmp=params[:page]? params[:page].to_i : 1
      @xs= Truong.where(["ten LIKE ?","%#{@tim}%"]).paginate(page: tmp, :per_page => 20)
      @count=20*tmp-19

      @trgs = Truong.order :ten
        respond_to do |format|
          format.html
          format.csv { send_data @trgs.as_csv }
      end
  end
  def new
    @x = Truong.new
  end
  def show
    @ys=@x.khoas.paginate(page: params[:page],:per_page=>10)
    @dkt=@x.dkis.count
    
  end
  def edit
  end
  def destroy
    if @x.user!=nil
      @x.user.destroy
    end
    @x.destroy
    flash[:success]="Xóa thành công ."
    redirect_to truongs_url
    
  end
  def update
      if @x.update(x_params)
        flash[:success] = "Cập nhật thành công "
        redirect_to @x
      else
        flash.now[:danger] = "Cập nhật thất bại !"
        render 'edit'
        
      end
  end
  def create
    @x=Truong.new(x_params)
      if @x.save
        flash[:success] = "Tạo mới thành công ."
        redirect_to @x
      else
        flash.now[:danger] = "Tạo mới thất bại !"
        render 'new'
      end
    
  end
  def import
      begin
        Truong.import(params[:file])
        flash[:success] = "File imported."
        redirect_to truongs_path
      rescue
        flash[:danger] = "Invalid CSV file format."
        redirect_to truongs_path 
      end
  end
private
  def set_x
    @x=Truong.find_by_id(params[:id])
    sida_url @x
  end
  def x_params
      params.require(:truong).permit(:id,:ten,:diachi,:website)
  end
  
  # Confirms a correct_truong.
      def correct_truong
        @trg = Truong.find_by_id(params[:id])
        unless current_user.truong==@trg
          flash[:danger] = "Đó không phải là trường của bạn !."
          redirect_to current_user.truong
        end
      end
end
