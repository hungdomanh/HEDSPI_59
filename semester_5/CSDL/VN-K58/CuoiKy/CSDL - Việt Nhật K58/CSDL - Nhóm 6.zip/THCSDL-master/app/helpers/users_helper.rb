module UsersHelper
	# Return true if user is admin 
    def ad?
      logged_in?&&current_user.id==1
    end
    def hs?
      logged_in? && current_user.id!=1 && current_user.hsinh!=nil
    end
    def trg?
      logged_in? && current_user.id!=1 && current_user.truong!=nil
    end
	
end
