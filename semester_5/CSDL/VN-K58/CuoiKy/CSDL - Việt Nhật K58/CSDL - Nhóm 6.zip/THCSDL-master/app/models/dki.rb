class Dki < ActiveRecord::Base
  belongs_to :hsinh
  belongs_to :truong
  belongs_to :khoa
  validates :hsinh_id,:truong_id,:khoa_id ,presence:true
  validates :diem ,numericality: { greater_than_or_equal_to: 0.5 }
end