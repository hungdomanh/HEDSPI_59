require 'test_helper'

class DialiTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
