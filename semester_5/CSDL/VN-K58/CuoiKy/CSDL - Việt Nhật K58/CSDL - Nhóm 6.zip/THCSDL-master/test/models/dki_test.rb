require 'test_helper'

class DkiTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
