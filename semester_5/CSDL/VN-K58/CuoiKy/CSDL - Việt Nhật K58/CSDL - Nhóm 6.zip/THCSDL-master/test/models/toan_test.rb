require 'test_helper'

class ToanTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
