require 'test_helper'

class VanTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
