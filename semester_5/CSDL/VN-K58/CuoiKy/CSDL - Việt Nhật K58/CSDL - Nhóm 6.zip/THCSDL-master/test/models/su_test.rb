require 'test_helper'

class SuTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
