require 'test_helper'

class CapnhatsControllerTest < ActionController::TestCase
  test "should get toan" do
    get :toan
    assert_response :success
  end

  test "should get van" do
    get :van
    assert_response :success
  end

  test "should get nn" do
    get :nn
    assert_response :success
  end

  test "should get sinh" do
    get :sinh
    assert_response :success
  end

  test "should get su" do
    get :su
    assert_response :success
  end

  test "should get hoa" do
    get :hoa
    assert_response :success
  end

  test "should get li" do
    get :li
    assert_response :success
  end

  test "should get dia" do
    get :dia
    assert_response :success
  end

end
