require 'test_helper'

class KhoiTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
