require 'test_helper'

class SinhTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
