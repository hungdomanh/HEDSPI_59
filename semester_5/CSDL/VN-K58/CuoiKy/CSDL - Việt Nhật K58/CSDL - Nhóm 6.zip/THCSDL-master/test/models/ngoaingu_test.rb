require 'test_helper'

class NgoainguTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
