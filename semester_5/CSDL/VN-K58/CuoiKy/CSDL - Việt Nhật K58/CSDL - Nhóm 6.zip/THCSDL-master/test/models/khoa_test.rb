require 'test_helper'

class KhoaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
